const express = require("express");
const router = express.Router();

const logementService = require('../service/logementService');
const { query } = require("../utils/db");


const logementRules = require('../utils/middleware/validation/logementRules')
const validate = require('../utils/middleware/validation/validate')






router.post("/", logementRules(), validate,

async (req, res) => {
    const { logement } = req.body;

    let logements = [];
    try {
        logements = await logementService.createLogement(logement)
    } catch (error) {
        console.error(error)
        res.status(500).send('Internal server error')
    }

    res.json(logements);
});




router.put("/:id", logementRules(), validate,

async (req, res) => {
    const { logement } = req.body;
    const paramsId = parseInt(req.params.id);
    let logements = []
    try {
        logements = await logementService.updateLogement(paramsId, logement)
    } catch (error) {
        console.error(error)
        res.status(500).send('Internal server error')
    }

    res.json(logements);
});



router.delete("/:id", async (req, res) => {
    let logements = [];
    const paramsId = parseInt(req.params.id);

    try {
        logements = await logementService.deleteLogement(paramsId)
    } catch (error) {
        console.error(error)
        res.status(500).send('Internal server error')
    }

    res.json(logements);
});






router.get("/", async (req, res) => {
// Si query string order=alphabetique
    if (req.query.order === 'alphabetique') {
        // Et si query string limit=5
        if (req.query.limit === 'top5') {
            let logements = [];
            try {
                logements = await logementService.getLogementsAlphabetiqueTop5()
            } catch (error) {
                console.error(error)
                res.status(500).send('Internal server error')
            }
            res.json(logements)
        // Sinon
        } else {
            let logements = [];
            try {
                logements = await logementService.getLogementsAlphabetique()
            } catch (error) {
                console.error(error)
                res.status(500).send('Internal server error')
            }
            res.json(logements)
        }
    }

    // http://localhost:9001/logements?order=id&limit=top5&start=2
    else if (req.query.order === 'id') {
        const idLogement = req.query.start
        if (req.query.limit === 'top5') {
            let logements = [];
            try {
                logements = await logementService.getLogementsOrderedByIdTop5(idLogement)
            } catch (error) {
                console.error(error)
                res.status(500).send('Internal server error')
            }
            res.json(logements);

        } else {
            let logements = [];
            try {
                logements = await logementService.getLogementsOrderedById(idLogement)
            } catch (error) {
                console.error(error)
                res.status(500).send('Internal server error')
            }
            res.json(logements);
        }
    }


    else if (req.query.order === 'note') {
        if (req.query.limit === 'top5') {
            let logements = [];
            try {
                logements = await logementService.getLogementsOrderedByNoteTop5()
            } catch (error) {
                console.error(error)
                res.status(500).send('Internal server error')
            }
            res.json(logements);

        } else {
            let logements = [];
            try {
                logements = await logementService.getLogementsOrderedByNote()
            } catch (error) {
                console.error(error)
                res.status(500).send('Internal server error')
            }
            res.json(logements);
        }
    }

    else if (req.query.order === 'reservation') {
        if (req.query.limit === 'top5') {
            let logements = [];
            try {
                logements = await logementService.getLogementsOrderedByReservationsTop5()

            } catch (error) {
                console.error(error)
                res.status(500).send('Internal server error')
            }
            res.json(logements)

        } else {
            let logements = [];
            try {
                logements = await logementService.getLogementsOrderedByReservations()

            } catch (error) {
                console.error(error)
                res.status(500).send('Internal server error')
            }
            res.json(logements)
        }
    }

////////// SINON, SI PAS DE QUERY STRING DERRIERE "LOGEMENTS", AFFICHER TOUS LES LOGEMENTS //////////////////
    else {
        let logements = [];
        try {
            logements = await logementService.getLogements();

        } catch (error) {
            console.error(error)
            res.status(500).send('Internal server error')
        }
        res.json(logements);
    }


});


// http://localhost:9001/logements/dates?start=2021-04-24&finish=2021-04-30
router.get("/dates", async (req, res) => {
    let logements = []
    // on déclare une date d'arrivée et une date de départ 
    const start = req.query.start
    const finish = req.query.finish

    try {
        // on appelle la fonction qui permet d'obtenir les logements sans réservation aux dates choisies et on passes les dates en paramètre
        logements = await logementService.getLogementsByDates(start, finish)
    } catch (error) {
        console.error(error)
        res.status(500).send('Internal server error')
    }

    res.json(logements)
})



    // logements = {
    //     titre: logements[0].titre
    // }

    
    // res.json({logements:logements[0].titre})

    // logements.forEach(logement => {
    //     res.json(logement.titre)
    // })




router.get("/:id", async (req, res) => {
    let logement = [];
    let paramsId = req.params.id
    try {
        logement = await logementService.getLogement(paramsId);

    } catch (error) {
        console.error(error)
        res.status(500).send('Internal server error')
    }
    res.json(logement);
});


// récupérer tous les logements d'un centre de vacances
router.get("/centresVacances/:idCentre", async (req, res) => {
    let logements = []
    const idCentre = req.params.idCentre;
    try {
        logements = await logementService.getLogementsByCentre(idCentre)

    } catch (error) {
        console.error(error)
        res.status(500).send('Internal server error')
    }
    res.json(logements)
})




router.get("/equipements/:idEquipement", async (req, res) => {
    let logements = []
    const idEquipement = req.params.idEquipement;
    try {
        logements = await logementService.getLogementsByEquipement(idEquipement)

    } catch (error) {
        console.error(error)
        res.status(500).send('Internal server error')
    }
    res.json(logements)
})


router.get("/regions/:id", async (req, res) => {
    let logements = []
    const idRegion = req.params.id

    try {
        logements = await logementService.getLogementsParRegion(idRegion)

    } catch (error) {
        console.error(error)
        res.status(500).send('Internal server error')
    }
    res.json(logements)

});








module.exports = router;