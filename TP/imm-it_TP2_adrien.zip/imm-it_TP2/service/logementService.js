const db = require("../utils/db");


const getLogements = async () => {

    let logements = []
    try {
       
        const query = await db.query('SELECT * FROM logement')
        logements = query.rows;
    } catch (error) {
        console.error(error)
    }
    return logements;
}

const getLogement = async (paramsId) => {
    let logement = []
    try {
        
        const query = await db.query('SELECT * FROM logement WHERE id = $1', [paramsId])
        logement = query.rows;
    } catch (error) {
        console.error(error)
    }
    return logement;
}



const createLogement = async (logement) => {
    let logements = []
    const titre = logement.titre;
    const description = logement.description;
    const nombrePieces = logement.nombre_pieces;
    const nombreChambres = logement.nombre_chambres;
    const surfaceInterieure = logement.surface_interieure;
    const surfaceExterieure = logement.surface_exterieure;
    const animaux = logement.animaux;
    const idCentre = logement.id_centre;

    try {
        await db.query('INSERT INTO logement (titre, description, nombre_pieces, nombre_chambres, surface_interieure, surface_exterieure, animaux, id_centre) VALUES ($1,$2,$3,$4,$5,$6,$7,$8)', [titre, description, nombrePieces, nombreChambres, surfaceInterieure, surfaceExterieure, animaux, idCentre]);
        logements = await getLogements()
    } catch (error) {
        console.error(error)
    }
    return logements;
}


const updateLogement = async (paramsId, logement) => {
    let logements = []
    const titre = logement.titre;
    const description = logement.description;
    const nombrePieces = logement.nombre_pieces;
    const nombreChambres = logement.nombre_chambres;
    const surfaceInterieure = logement.surface_interieure;
    const surfaceExterieure = logement.surface_exterieure;
    const animaux = logement.animaux;
    const idCentre = logement.id_centre;
    try {
        await db.query('UPDATE logement SET titre = $1 WHERE id = $2', [titre, paramsId]);
        await db.query('UPDATE logement SET description = $1 WHERE id = $2', [description, paramsId]);
        await db.query('UPDATE logement SET nombre_pieces = $1 WHERE id = $2', [nombrePieces, paramsId]);
        await db.query('UPDATE logement SET nombre_chambres = $1 WHERE id = $2', [nombreChambres, paramsId]);
        await db.query('UPDATE logement SET surface_interieure = $1 WHERE id = $2', [surfaceInterieure, paramsId]);
        await db.query('UPDATE logement SET surface_exterieure = $1 WHERE id = $2', [surfaceExterieure, paramsId]);
        await db.query('UPDATE logement SET animaux = $1 WHERE id = $2', [animaux, paramsId]);
        await db.query('UPDATE logement SET id_centre = $1 WHERE id = $2', [idCentre, paramsId]);


        logements = await getLogements()
    } catch (error) {
        console.error(error)
    }

    return logements;
}


const deleteLogement = async (paramsId) => {
    let logements = []
    try {
        await db.query('DELETE FROM logement WHERE id = $1', [paramsId])
        logements = await getLogements()
    } catch (error) {
        console.error(error)
    }

    return logements
}


const getLogementsAlphabetique = async () => {
    let logements = []

    try {
        const query = await db.query('SELECT logement.titre FROM logement ORDER BY logement.titre')
        logements = query.rows;

    } catch (error) {
        console.error(error);
    }

    return logements;
}

const getLogementsAlphabetiqueTop5 = async () => {
    let logements = []

    try {
        const query = await db.query('SELECT logement.titre FROM logement ORDER BY logement.titre LIMIT 5')
        logements = query.rows;

    } catch (error) {
        console.error(error);
    }

    return logements;
}



const getLogementsOrderedById = async (idLogement) => {
    let logements = [];
    try {
        const query = await db.query('SELECT logement.id, logement.titre FROM logement WHERE logement.id >= $1 ORDER BY logement.id', [idLogement])
        logements = query.rows

    } catch (error) {
        console.error(error)
    }
    return logements
}

const getLogementsOrderedByIdTop5 = async (idLogement) => {
    let logements = [];
    try {
        const query = await db.query('SELECT logement.id, logement.titre FROM logement WHERE logement.id >= $1 ORDER BY logement.id LIMIT 5', [idLogement])
        logements = query.rows

    } catch (error) {
        console.error(error)
    }
    return logements
}


const getLogementsOrderedByNote = async () => {
    let logements = [];
    try {
        const query = await db.query('SELECT logement.titre, round(avg(commentaire.note),1) as note_moyenne FROM logement JOIN avis ON logement.id = avis.id_logement JOIN commentaire ON avis.id_commentaire = commentaire.id GROUP BY logement.titre ORDER BY note_moyenne DESC')
        logements = query.rows

    } catch (error) {
        console.error(error)
    }
    return logements
}

const getLogementsOrderedByNoteTop5 = async () => {
    let logements = [];
    try {
        const query = await db.query('SELECT logement.titre, round(avg(commentaire.note),1) as note_moyenne FROM logement JOIN avis ON logement.id = avis.id_logement JOIN commentaire ON avis.id_commentaire = commentaire.id GROUP BY logement.titre ORDER BY note_moyenne DESC LIMIT 5')
        logements = query.rows

    } catch (error) {
        console.error(error)
    }
    return logements
}


const getLogementsOrderedByReservations = async () => {
    let logements = []

    try {
        const query = await db.query('SELECT logement.titre, count(reservation.id) as nombre_reservations FROM logement LEFT JOIN reservation ON logement.id = reservation.id_logement GROUP BY logement.titre ORDER BY nombre_reservations DESC')
        logements = query.rows;
    } catch (error) {
        console.error(error);
    }

    return logements
}


const getLogementsOrderedByReservationsTop5 = async () => {
    let logements = []

    try {
        const query = await db.query('SELECT logement.titre, count(reservation.id) as nombre_reservations FROM logement LEFT JOIN reservation ON logement.id = reservation.id_logement GROUP BY logement.titre ORDER BY nombre_reservations DESC LIMIT 5')
        logements = query.rows;
    } catch (error) {
        console.error(error);
    }

    return logements
}


// récupérer tous les logements d'un centre de vacances
const getLogementsByCentre = async (idCentre) => {
    let logements = []
    try {
        const query = await db.query('SELECT logement.titre, centre_vacances.id as id_centre, centre_vacances.nom as nom_centre, centre_vacances.ville as lieu_centre FROM logement JOIN centre_vacances ON logement.id_centre = centre_vacances.id WHERE centre_vacances.id = $1', [idCentre]);
        logements = query.rows;
        
    } catch (error) {
        console.error(error) 
    }
    return logements
}




const getLogementsByEquipement = async (idEquipement) => {
    let logements = []

    try {
        const query = await db.query('SELECT logement.titre, equipement.nom_equipement FROM logement JOIN logement_equipement ON logement.id = logement_equipement.id_logement JOIN equipement ON logement_equipement.id_equipement = equipement.id WHERE equipement.id = $1', [idEquipement])
        logements = query.rows;
    } catch (error) {
        console.error(error);
    }
    return logements;
}


const getLogementsParRegion = async (idRegion) => {
    let logements = []

    try {
        const query = await db.query('SELECT logement.titre, centre_vacances.nom, region.nom_region FROM logement JOIN centre_vacances ON logement.id_centre = centre_vacances.id JOIN region ON region.id = centre_vacances.id_region WHERE region.id = $1', [idRegion])
        logements = query.rows;
    } catch (error) {
        console.error(error);
    }
    return logements;
}


// http://localhost:9001/logements/dates?start=2021-04-24&finish=2021-04-30
const getLogementsByDates = async (start, finish) => {

// On déclare un tableau de logements
    let logements = []
    try {
        //On vient récupérer toutes les réservations existantes quel que soit le logement, y compris les logements sans réservation
        const query = await db.query('SELECT logement.id, logement.titre, reservation.date_arrivee, reservation.date_depart FROM logement LEFT JOIN reservation ON logement.id = reservation.id_logement')
        logements = query.rows;
    } catch (error) {
        console.error(error);
    }

    // on déclare une date d'arrivée et une date de départ qu'on récupère des paramètres
    const choixArrivee = new Date(start);
    const choixDepart = new Date(finish);


    // on créé un tableau contenant les logements non-disponibles aux dates choisies
    const logementsNonDispos = logements.filter(logement => {
        return !((choixArrivee < logement.date_arrivee && choixDepart < logement.date_arrivee) || (choixArrivee > logement.date_depart))
    });

    console.log('\nListe de toutes les réservations tous logements confondus :\n')
    console.log(logements)
    console.log('\nLogements non-dispos :\n')
    console.log(logementsNonDispos)

    // on créé un autre tableau avec les id de ces logements non-disponibles
    let idNonDispos = [];

    logementsNonDispos.forEach(logement => {
        idNonDispos.push(logement.id)
    });

    console.log('\nListe des ID non-disponibles :\n')
    console.log(idNonDispos)

    let logementsDispos = [];

    
    logements.forEach(logement => {
        // on repère dans le premier tableau les logements dont l'id est disponible
        if (!idNonDispos.includes(logement.id)) {
            // on vérifie si le logement n'existe pas déja dans les logements dispos pour éviter les doublons
            let exist = false
            exist = isExist(logement.id, logementsDispos)
            if (!exist) {
                // on insère le logement dans la liste des logements dispos
                logementsDispos.push(logement)
            }
        }
    })

    console.log(`\nVoici les logements disponibles à vos dates : \n`)
    
    logementsDispos.forEach(logement => {
        console.log(logement.titre);

    })
    // on retourne les logements dispos 
    return logementsDispos
}


function isExist(idLogement, logementsDispos) {
    let exist = false
    logementsDispos.forEach(element => {
        if (idLogement == element.id) {
            exist = true;
        }
    })
    return exist;
}



module.exports = { getLogements, getLogement, createLogement, updateLogement, deleteLogement, getLogementsAlphabetique, getLogementsOrderedById, getLogementsOrderedByNote, getLogementsOrderedByReservations, getLogementsByCentre, getLogementsByEquipement, getLogementsAlphabetiqueTop5, getLogementsOrderedByIdTop5, getLogementsOrderedByNoteTop5, getLogementsOrderedByReservationsTop5, getLogementsParRegion, getLogementsByDates };