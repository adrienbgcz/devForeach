<template>
  <div>
    <div class="inputsTop">
        <div class="checkboxesTop">
          <input type="checkbox" name="termines"><label>ToDos terminés</label>
          <input type="checkbox" name="enCours"><label>ToDos en cours</label>
        </div>
        <select name="etiquettes">
          <option selected>Choisissez une étiquette</option>
          <option>etiquette 1</option>
          <option>etiquette 2</option>
          <option>etiquette 3</option>
          <option>etiquette 4</option>
        </select>
    </div>

    <TodoTemplate v-for="todos in todosList" :key="todos.id" :todosProps="todos"/>
    <FormulaireTemplate v-if="formTodo" />
    
    <button @click="formTodo=!formTodo">Add Todo</button>

  </div>
</template>

<script>
import TodoTemplate from "../components/TodoTemplate.vue"
import FormulaireTemplate from "../components/FormulaireTemplate.vue"

export default {
  name: 'HomeView',
  components: {
    TodoTemplate,
    FormulaireTemplate
  }, 
  data: function() {
    return {
      todosList: [], 
      formTodo: false
    }
  },
  methods: {
    getData: async function() {
      try {
        const response = await fetch("http://localhost:3000/todos")
        const data = await response.json()
        this.todosList = data
        console.log(data)
      } catch(error) {
        console.log(error)
      }
    }
  },
  created: function() {
    this.getData()
  }
}

</script>

<style scoped>

.inputsTop {
  display: flex;
  justify-content: space-around;
  align-items: center;

}

.checkboxesTop {
display: flex;
align-items: center;


}

.listTop {

}
</style>
