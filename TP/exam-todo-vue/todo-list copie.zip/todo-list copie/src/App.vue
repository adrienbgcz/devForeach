<template>
  <div>
    <header><span>Mes ToDos</span></header>

    <router-link to="/"></router-link>
    <router-view />

    <footer>GPasLeTemps SAS</footer>
  </div>
</template>

<style>

header {
  font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
  font-size: 30px;
  color: white;
  background-color: #4B92D7;
  
}

span {
  margin-left: 100px
}

footer {
    font-family: lato;
    background-color: black;
    display: flex;
    justify-content: center;
    padding: 20px;
    margin-top: 300px;
    color:white;
}


/* * {
  border: solid;
  border-color: red;
  border-width: 1px;
} */

</style>
