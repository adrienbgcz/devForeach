<template>
  <div>
    <!-- <EtiquetteTemplate :etiquetteProps="etiquette" /> -->
    
    <div class="todo">
      <div class="etiquette">{{todosProps.etiquettes}}</div>
      <div>{{todosProps.nom}}</div>
      <div>{{todosProps.description}}</div>
      <div>{{todosProps.date_fin}}</div>
    </div>
  </div>
  
</template>


<script>
import EtiquetteTemplate from "../components/EtiquetteTemplate.vue"

export default {
  name: 'TodoTemplate',
  props: ["todosProps"], 
  components: {
    EtiquetteTemplate
  }, 
  data: function() {
    return {
      etiquettesList: [], 
    }
  },
  methods: {
  //   getData: async function() {
  //     try {
  //       const response = await fetch("http://localhost:3000/etiquettes")
  //       const data = await response.json()
  //       this.etiquettesList = data
  //       console.log(data)
  //     } catch(error) {
  //       console.log(error)
  //     }
  //   }
  // },
  // created: function() {
  //   this.getData()
   }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

.todo {
  margin:auto;
  width: 75%;
  border: solid;
}

.etiquette {
 
}

</style>
