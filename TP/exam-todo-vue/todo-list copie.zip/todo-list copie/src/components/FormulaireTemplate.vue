<template>
<section>
    <span>Ajouter une ToDo</span>
    <div class="allForm">
        <input type="text" placeholder="Titre" >
        <textarea placeholder="Description"/>
        <input type="date" >
        <select name="etiquettes">
            <option selected>Choisissez une étiquette</option>
            <option>etiquette 1</option>
            <option>etiquette 2</option>
            <option>etiquette 3</option>
            <option>etiquette 4</option>
        </select>
    </div>
</section>
  
</template>

<script>
export default {

}
</script>

<style>
.allForm {
    display: flex;
    flex-direction: column;
    margin-top : 100px;
    width: 75%;
    margin:auto
}

section {
    margin-top: 50px;
}

input {
    margin-top: 20px;
    height: 30px;
}

textarea {
    margin-top: 20px;
    height: 60px;
}

select {
    margin-top: 20px;
    height: 25px;
}
    

</style>