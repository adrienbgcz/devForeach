<template>
  <div class="etiquette">
      <span>{{etiquetteProps.nom}}</span>
  </div>
</template>

<script>
export default {
    name: 'EtiquetteTemplate',
    props: ["etiquetteProps"]

}
</script>

<style scoped>
.etiquette {
    background-color: #4B92D7;

}

</style>