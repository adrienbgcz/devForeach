const movies = [
  {
    id: 1,
    title: "La communauté de l'anneau",
    director: "P.Jackson",
    year: "2001"
  },
  {
    id: 2,
    title: "Les deux tours",
    director: "P.Jackson",
    year: "2003"
  },
  {
    id: 3,
    title: "Le retour du roi",
    director: "P.jackson",
    year: "2005"
  }
];

module.exports = movies;
