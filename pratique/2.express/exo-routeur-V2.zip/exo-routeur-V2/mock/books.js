const books = [
  {
    id: 1,
    title: "Le seigneur des anneaux",
    author: "J.R.R Tolkien",
    year: "1972"
  },
  {
    id: 2,
    title: "Les promesses de l'aube",
    author: "R.Gary",
    year: "1986"
  },
  {
    id: 3,
    title: "Le livre des leurres",
    author: "E.Cioran",
    year: "1967"
  }
];

module.exports = books;
