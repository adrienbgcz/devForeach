const videogames = [
  {
    id: 1,
    title: "Mario Bros",
    producer: "Nintendo",
    year: "1885"
  },
  {
    id: 2,
    title: "Sonic",
    producer: "Sega",
    year: "1988"
  },
  {
    id: 3,
    title: "Street Fighter",
    producer: "Capcom",
    year: "1995"
  }
];

module.exports = videogames;


{
     "newVideogame" : {
      "id": 4,
      "title": "Mon jeu vidéo",
      "producer": "Moi",
      "year": "2021"
    }
}

{
     "updatedVideogame" : {
      "id": 3,
      "title": "Mon jeu vidéo",
      "producer": "Moi",
      "year": "2021"
    }
}


