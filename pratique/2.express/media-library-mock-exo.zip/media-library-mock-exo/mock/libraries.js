const libraries = [
  {
    id: 1,
    name: "Ma collection Fantastique",
    person_id: 1
  },
  {
    id: 2,
    name: "Ma collection Comédie",
    person_id: 2
  }
];
module.exports = libraries;

{
    "newLibrary" : {
        "id" : 3,
        "name" : "Ma librairie",
        "person_id" : 3
    }
}

{
    "updatedLibrary" : {
        "id" : 2,
        "name" : "Ma librairie",
        "person_id" : 2
    }
}