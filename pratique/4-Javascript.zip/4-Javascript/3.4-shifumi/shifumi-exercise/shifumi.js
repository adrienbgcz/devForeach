const symbols = [
  {
    name: "rock",
    img: "./img/rock.png"
  },
  {
    name: "paper",
    img: "./img/paper.png"
  },
  {
    name: "scissors",
    img: "./img/scissors.png"
  },
  {
    name: "lizard",
    img: "./img/lizard.png"
  },
  {
    name: "spock",
    img: "./img/spock.png"
  }
];



const opponent = document.querySelector("opponent")
const img = document.querySelector("main img")

let choice = ''



  img.addEventListener("click", choice = img)

console.log(choice)

