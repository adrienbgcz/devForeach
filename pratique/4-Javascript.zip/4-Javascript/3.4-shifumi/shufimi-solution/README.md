# ***BIG BANG SHIFUMI***

        Pour passer le temps lors des pauses dans votre apprentissage, vous décidez de créer un jeu de shifumi selon les règles énoncées dans la série The big bang theory

        Ces règles sont celles du jeu Pierre-Feuille-Ciseau-Lézard-Spock :

        - Les ciseaux coupent le papier
        - Le papier bat la pierre
        - La pierre écrase le lézard
        - Le lézard empoisonne Spock.
        - Spock écrabouille les ciseaux
        - Les ciseaux décapitent le lézard
        - Le lézard mange le papier
        - Le papier repousse Spock
        - Spock détruit la pierre
        - La pierre bat les ciseaux


***SPECIFICATIONS***

        - Quand l'utilisateur clique sur une image, la stocker
        - Quand l'utilisateur clique sur une image, l'adversaire choisit une image au hasard
        - Quand l'utilisateur et l'adversaire ont chacun choisi une image, déterminer qui remporte la manche
        - Quand l'utilisateur ou l'adversaire remporte 2 manches, alerter l'utilisateur sur le vainqueur du match
        - L'image qui remporte la manche devra être entourée en vert
        - L'image qui perd la manche devra être entourée en rouge
        - Dans le cas d'un ex aequo, chaque image devra être entourée en orange
        - A chaque fois que l'utilisateur clique sur une image, la couleur qui entoure l'image choisit précédemment doit être supprimée.
        - A la fin d'un match, l'affichage de l'adversaire doit être vide

***FONCTIONNALITES***

        - Définir le choix de l'utilisateur
        - Définir le choix de l'adversaire
        - Définir qui remporte une manche
        - Définir qui remporte un match
        - Mettre à jour l'affichage
        - Permettre l'écoute d'un événement sur chaque image de l'utilisateur
        - Au clic sur une image de l'utilisateur, lancer une manche
        - Définir la bonne couleur pour l'image de l'utilisateur en rapport avec l'image de l'adversaire
        - Appliquer ces couleurs à chaque fin de manche
        - Supprimer toutes les couleurs des images de l'utilisateur
        - Vider l'affichage de l'adversaire avant chaque nouvelle manche


