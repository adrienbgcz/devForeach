# **Chuck Norris Joke Generator**

    Créez un générateur de blagues à propos de Chuck Norris en utilisant une API, la méthode fetch, la syntaxe async await, et la gestion d'erreur

Le modèle HTML à reproduire est le suivant : 

    <p>une blague</p>
    <img src="la src de licône " alt="">
    <p>créé le ..........</p>

L'url de l'API à contacter est la suivante : 

    https://api.chucknorris.io/jokes/random 

Fonctionnalité :

    Quand vous clickez sur l'icône du visage de Chuck Norris, une nouvelle blague s'affiche.